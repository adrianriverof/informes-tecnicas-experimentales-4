

En este fichero está todo el material que he utilizado para realizar las prácticas.

Las hojas de cálculo están cada una en su carpeta correspondiente a cada práctica. Para las gráficas he utilizado el programa SciDAVis (es gratuito), que utiliza la extensión .sciprj



